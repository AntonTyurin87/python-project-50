# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.scripts']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.5',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/AntonTyurin87/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/AntonTyurin87/python-project-50/actions) [![Python CI](https://github.com/AntonTyurin87/python-project-50/actions/workflows/pyci.yml/badge.svg)](https://github.com/AntonTyurin87/python-project-50/actions/workflows/pyci.yml) <a href="https://codeclimate.com/github/AntonTyurin87/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/8559a89a1e3a2f495249/maintainability" /></a> <a href="https://codeclimate.com/github/AntonTyurin87/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/8559a89a1e3a2f495249/test_coverage" /></a>\n\n[![asciicast](https://asciinema.org/a/p5PLICUICkCca1LAUdwLa3QMV.svg)](https://asciinema.org/a/p5PLICUICkCca1LAUdwLa3QMV)\n\n\n\n\n',
    'author': 'Anton Tyurin',
    'author_email': 'AntonTyurin87@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
