### Hexlet tests and linter status:
[![Actions Status](https://github.com/AntonTyurin87/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/AntonTyurin87/python-project-50/actions) [![Python CI](https://github.com/AntonTyurin87/python-project-50/actions/workflows/pyci.yml/badge.svg)](https://github.com/AntonTyurin87/python-project-50/actions/workflows/pyci.yml) <a href="https://codeclimate.com/github/AntonTyurin87/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/8559a89a1e3a2f495249/maintainability" /></a> <a href="https://codeclimate.com/github/AntonTyurin87/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/8559a89a1e3a2f495249/test_coverage" /></a>

[![asciicast](https://asciinema.org/a/p5PLICUICkCca1LAUdwLa3QMV.svg)](https://asciinema.org/a/p5PLICUICkCca1LAUdwLa3QMV)




