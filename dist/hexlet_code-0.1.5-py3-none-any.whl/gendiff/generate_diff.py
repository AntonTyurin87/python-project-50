# Здесь будет функция поиска отличий файлов json

import json

def generate_diff():
    pass

a = json.load(open('fixtures/file1.json'))

print(a)

'''
json.load(open('path/to/file.json'))
'''